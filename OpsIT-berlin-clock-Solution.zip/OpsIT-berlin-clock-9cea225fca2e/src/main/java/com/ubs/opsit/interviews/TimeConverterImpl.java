package com.ubs.opsit.interviews;

import java.util.Arrays;

public class TimeConverterImpl implements TimeConverter {

	@Override
	public String convertTime(String aTime) {
		int[] timearr = Arrays.asList(aTime.split(":")).stream().mapToInt(Integer::parseInt).toArray();
		return  getSecs(timearr[2]) + System.lineSeparator()
				+ getTopHrs(timearr[0]) + System.lineSeparator()
				+ getBottomHrs(timearr[0]) + System.lineSeparator() 
				+ getTopMins(timearr[1]) + System.lineSeparator()
				+ getBottomMins(timearr[1]);
	}

	private String getSecs(int timeval) {
		if (timeval % 2 == 0)
			return "Y";
		else
			return "O";
	}

	private String getTopHrs(int timeval) {
		return getOnOff(4, getToptimevalOfOnSigns(timeval));
	}

	private String getBottomHrs(int timeval) {
		return getOnOff(4, timeval % 5);
	}

	private String getTopMins(int timeval) {
		return getOnOff(11, getToptimevalOfOnSigns(timeval), "Y").replaceAll("YYY", "YYR");
	}

	private String getBottomMins(int timeval) {
		return getOnOff(4, timeval % 5, "Y");
	}

	private String getOnOff(int lamps, int onSigns) {
		return getOnOff(lamps, onSigns, "R");
	}

	private String getOnOff(int lamps, int onSigns, String onSign) {
		String out = "";
		for (int i = 0; i < onSigns; i++) {
			out += onSign;
		}
		for (int i = 0; i < (lamps - onSigns); i++) {
			out += "O";
		}
		return out;
	}

	private int getToptimevalOfOnSigns(int timeval) {
		return (timeval - (timeval % 5)) / 5;
	}

}
